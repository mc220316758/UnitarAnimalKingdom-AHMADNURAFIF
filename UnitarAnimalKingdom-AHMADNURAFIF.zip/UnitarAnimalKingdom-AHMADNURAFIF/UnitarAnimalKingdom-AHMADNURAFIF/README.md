# UnitarAnimalKingdom
Animal Kingdom
Project Softwaredevelopment - final
Final Project - Animal Kingdom
This assignment will give you practice with defining classes. You are to write a set of classesthat define
the behavior of certain animals. You will be given a program that runs a simulation of a world with
many animals wandering around in it. Different kinds of animals will behave in different ways and you
are defining those differences.
